module Main (main) where

import Shortener (shortener)

main :: IO ()
main =
  shortener